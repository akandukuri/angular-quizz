import { Component, OnInit } from '@angular/core';
import { Http, Headers, RequestOptionsArgs, RequestMethod, ResponseContentType } from '@angular/http';
import * as http from "http";
import {$} from "protractor";
//import {HttpClientModule} from '@angular/common/http';
// import { HttpHelperService } from '../../shared/E:\avani\version2/http-helper.service';

@Component({
  selector: 'app-auth-contact',
  templateUrl: './authContact.component.html',
  styleUrls: ['./authContact.component.css']
})
export class AuthContactComponent implements OnInit {

  private title: string;
  private firstname: string;
  private middlename: string;
  private lastname: string;
  private suffix: string;
  private phonenumber: string;
  private extension: string;
  private phonetype: string;


  constructor () {
    this.firstname = 'Test name';
    this.title = "Mr";
  }
  ngOnInit(){
    console.log('Component Initialized!');

  }

  process() {
    console.log(this.firstname);
    console.log(this.title);
    var payload ={
         'title':this.title,
         'firstname':this.firstname
       };
   // http.post('', payload)


    //Construct payload
    // var payload ={
    //   'title':this.title,
    //   'firstname':this.firstname
    // };

    //Make the api call
    // this.httpHelper.postJson('http://sampleurl', payload)
    //   .subscribe(
    //     successCallback,
    //     errorCallback,
    //   );

  }

  protected successCallback (resultPayload: any) {

}
  protected errorCallback (resultPayload: any) {

  }
}



