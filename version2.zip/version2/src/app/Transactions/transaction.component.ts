import { Component, OnInit } from '@angular/core';
import { Http, Headers, RequestOptionsArgs, RequestMethod, ResponseContentType } from "@angular/http";
import {UserService} from '../shared/user.service';
import * as CryptoJS from 'crypto-js'
declare var md5: any;

@Component({
    selector: 'transaction-payment',
    templateUrl: './transaction.component.html',
    styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

    private x_login: string;
    private x_amount: Number;
    private x_fp_sequence: string;
    private x_fp_timestamp: number;
    private x_fp_hash: string;  
    private x_currency_code: string;
    private x_show_form: string;
    private x_last_name: string;
    private x_invoice_num: string;
    /*$x_user3 for showing AWHR account number on the Payeezy Hosted Payment Page*/
    private x_user3: string;
    private x_test_request: string;
    private x_relay_response: string;
    
    //Form action
    private action: string;

    private transaction_key: string;
    private hmac_data: string;
    private csrf_token_name: string;
    private ccEazyAPIKey : string;

    constructor(private httpObject: Http, private service:UserService,) {
        var max = 100000;
        var min = 1000;
        
        this.x_login = 'HCO-CONTR-277';
        this.x_amount = 12.23;
        //this.x_fp_sequence = (Math.floor(Math.random() * (max - min + 1)) + min + 135565).toString();
        this.x_fp_sequence='194277';
        this.x_fp_timestamp;
       // this.x_fp_hash='680b4ce5f07b2484f4321c32492f5e6b';
        this.x_currency_code = 'USD';
        this.x_show_form='PAYMENT_FORM';
        this.x_last_name='Burkindine';
        this.x_invoice_num = '132432141';
        this.x_user3='132432141'
        this.x_test_request='TRUE';
        this.x_relay_response='';
    }
     ngOnInit() {
        var data = this.service.getData();
        this.x_amount = data.amount;
    }

    randomhashgenerator(length, chars){
        var result='';
          for (var i = length; i > 0; --i)
             result += chars[Math.round(Math.random() * (chars.length - 1))];
             return result;
    }

    resetTimestamp(){
     this.x_fp_timestamp =Math.floor(Date.now() / 1000);
     var transactionKey ='IsfzH1wcxDufJrxxjbvU';

     var message = this.x_login+'^'+this.x_fp_sequence+'^'+this.x_fp_timestamp+'^'+this.x_amount+'^'+this.x_currency_code;
     var hash = CryptoJS.HmacMD5( message, transactionKey);
     this.x_fp_hash = hash.toString()
    }

    processCreditCardTransaction() {

        var nonce = Math.random() * 1000000000000000000;
        //var timeInMillis = new Date().getTime();
        //this.x_fp_timestamp = timeInMillis / 1000;
        this.x_fp_timestamp =Math.floor(Date.now() / 1000);
        //this.x_user3 = this.x_invoice_num;

        this.hmac_data = this.x_login + "^" + this.x_fp_sequence + "^" + this.x_fp_timestamp + "^" + this.x_amount + "^" + this.x_currency_code;
        //this.x_fp_hash = hash_hmac('MD5', $hmac_data, $transaction_key);
        this.x_fp_hash = md5(this.hmac_data, this.transaction_key);

        this.csrf_token_name = 'fdoa-a480ce8951daa73262734cf102641994c1e55e7cdf4c02b6';

        let RequestOptionsArgsObjecct: RequestOptionsArgs = {} as RequestOptionsArgs;

        let headersObject = new Headers({
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'nonce': nonce,
            'timestamp': this.x_fp_timestamp,
            //'Authorization': 'ZGZhZjRiZGM2NzZlNDY2YThmMWFkMTZjMDcyOGEzMDM5MzVlZWZjMTUyYzA2OTZhMjc4YTQ4YTVjNmY5NzMyNQ=='
            'Authorization': this.x_fp_hash // 'ZGZhZjRiZGM2NzZlNDY2YThmMWFkMTZjMDcyOGEzMDM5MzVlZWZjMTUyYzA2OTZhMjc4YTQ4YTVjNmY5NzMyNQ=='
        });

        RequestOptionsArgsObjecct.headers = headersObject;
        RequestOptionsArgsObjecct.method = RequestMethod.Post;
        RequestOptionsArgsObjecct.url = "https://api.payeezy.com/v1/transactions";
        RequestOptionsArgsObjecct.responseType = ResponseContentType.Json;


        var testObj = {
            merchant_ref: 'Astonishing-Sale',
            transaction_type: 'authorize',
            method: 'credit_card',
            amount: this.x_amount,
            currency_code: this.x_currency_code
            // credit_card: {
            //     type: 'visa',
            //     cardholder_name: this.x_login,
            //     card_number: this.cc_Number,
            //     exp_date: this.cc_Exp_Date,
            //     cvv: this.cc_CVV_No
            // }
        };
        this.httpObject.post('https://api.payeezy.com/v1/transactions', JSON.stringify(testObj), RequestOptionsArgsObjecct)
            .subscribe((resposeFromApi) => {
                  console.log('Response : ' + resposeFromApi);
            })

    }


}


