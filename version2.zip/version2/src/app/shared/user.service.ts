import {Injectable} from '@angular/core';


@Injectable()
export class UserService{

    private userData ={
        customer_name : 'JANET MILLER',
        awhr_account_number:'741071919291',
        amount:0
    }

    constructor() {
    }

    getData(){
        return this.userData;
    }

    setAmount(amount){
        this.userData.amount = amount;
    }
}