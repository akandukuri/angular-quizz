import { Component, OnInit } from '@angular/core';
import { Http, Headers, RequestOptionsArgs, RequestMethod, ResponseContentType } from "@angular/http";
import {ActivatedRoute, Router} from '@angular/router';
import {UserService} from '../shared/user.service';


@Component({
    selector: 'payment',
    templateUrl: './payment.component.html',
    styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

    parentRouter:Router; 

    private customer_name: string;
    private awhr_account_number: string;
    private amount:Number;

    constructor(
        private route:ActivatedRoute,
        private service:UserService,
        private router:Router) {
       
       //this.customer_name ='JANET MILLER';
       //this.awhr_account_number ='741071919291';
    }
    ngOnInit() {
        var data = this.service.getData();
        this.customer_name = data.customer_name
        this.awhr_account_number = data.awhr_account_number;
        this.amount = data.amount;
    }

    processPayment() {
         this.service.setAmount(this.amount);
         this.router.navigate(['/transaction']);
    }
}
