import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import{Routes, RouterModule} from '@angular/router';
import { HttpModule } from "@angular/http";
import { TransactionComponent } from './Transactions/transaction.component';
import{PaymentComponent} from './payment/payment.component';
import { UserService} from './shared/user.service';
import {AuthContactComponent} from "./authContact/authContact.component";
import {HttpClientModule} from '@angular/common/http';


const appRoutes :Routes = [
  { path: '' , component: PaymentComponent},
  { path: 'payment' , component: PaymentComponent},
  { path: 'transaction' ,component: TransactionComponent},
  { path: 'addAuth', component:AuthContactComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    TransactionComponent,
    PaymentComponent,
    AuthContactComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(
      appRoutes,
      {enableTracing: true}
    )
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
