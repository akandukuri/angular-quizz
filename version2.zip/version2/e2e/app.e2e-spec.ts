import { AwhrproPage } from './app.po';

describe('awhrpro App', () => {
  let page: AwhrproPage;

  beforeEach(() => {
    page = new AwhrproPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
